INSTALLATION INSTRUCTIONS:


ИНСТРУКЦИЯ ПО УСТАНОВКЕ:


INSTRUKCE K INSTALACI:


---------------------------------------------------------------------------------------------------------------------------


ENG:


Copy the file called "joeciv.sds" from the "Suit" folder and paste it here - 


C: \ Program Files (x86) \ Steam \ steamapps \ common \ Mafia II \ pc \ sds \ hchar


Don't forget to keep a backup of the unmodified file! Enjoy! :-)


---------------------------------------------------------------------------------------------------------------------------


RUS:


Скопируйте файл "joeciv.sds" из папки "Suit" и вставьте его сюда -


C: \ Program Files (x86) \ Steam \ steamapps \ common \ Mafia II \ pc \ sds \ hchar


Не забудьте сделать копию неизмененного файла! Наслаждайтесь! :-)


---------------------------------------------------------------------------------------------------------------------------


CZ:


Zkopírujte soubor s názvem "joeciv.sds" ze složky "Suit" a vložte jej sem -


C: \ Program Files (x86) \ Steam \ steamapps \ common \ Mafia II \ pc \ sds \ hchar


Nezapomeňte si vytvořit kopii nezměněného souboru! Užívat si! :-)

